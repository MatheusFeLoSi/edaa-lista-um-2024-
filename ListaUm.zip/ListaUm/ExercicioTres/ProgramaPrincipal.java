package ExercicioTres;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        
        Aluno aluno = new Aluno("Matheus Felipe", 20, "Ciências da Computção");
        Professor professor = new Professor("Daniel", 36, 12345, "Ciências da computação"); 
        Universidade universidade = new Universidade("UNA", "Centro de contagem", 1097720931, 7);
        Disciplina disciplina = new Disciplina("Programação", 70, 6);
    
        System.out.println("Nome: " + aluno.getNome());
        System.out.println("Curso: " + aluno.getCurso());
        System.out.println("----------------------------");
        System.out.println("Professor: " + professor.getNome());
        System.out.println("Materia: " + professor.getMateria());
        System.out.println("----------------------------");
        System.out.println("Universidade: " + universidade.getNome());
        System.out.println("Localização: " + universidade.getLocalizacao());
        System.out.println("Nota de Qualidade: " + universidade.getNotaDeQualidade());
        System.out.println("-----------------------------");
        System.out.println("Nome da matéria: " + disciplina.getNomeDaMateria());
        System.out.println("Nota miníma para aprovação: " + disciplina.getValorMin() + " pontos");
        System.out.println("Duração do curso: " + disciplina.getTempodeCurso() + " meses"); 
    }
}
