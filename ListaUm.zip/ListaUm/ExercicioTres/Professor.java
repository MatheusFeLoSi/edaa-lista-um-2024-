package ExercicioTres;

public class Professor {
    private String nome;
    private int idade;
    private int id;
    private String materia;     

public Professor(String nome, int idade, int id, String materia) {
    this.nome = nome;
    this.idade = idade;
    this.id = id;
    this.materia = materia; 
    }

    public String getNome() {
        return nome;
    }
    public int getidade() {
        return idade;
    }
    public int getid() {
        return id; 
    }
    public String getMateria() {
        return materia; 
    }
}