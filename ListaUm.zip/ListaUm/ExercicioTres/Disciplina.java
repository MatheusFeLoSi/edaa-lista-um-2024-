package ExercicioTres;

public class Disciplina {
    private String nomeDaMateria;
    private int ValorMin;
    private int tempoDeCurso;

    public Disciplina (String nomeDaMateria, int ValorMin, int tempoDeCurso) {
        this.nomeDaMateria = nomeDaMateria;
        this.ValorMin = ValorMin;
        this.tempoDeCurso = tempoDeCurso;
    }

    public String getNomeDaMateria() {
        return nomeDaMateria;
    }
    public int getValorMin() {
        return ValorMin;
    }
    public int getTempodeCurso() {
        return tempoDeCurso;
    }
}