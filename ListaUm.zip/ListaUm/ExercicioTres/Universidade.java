package ExercicioTres;

public class Universidade {
    private String nome; 
    private String localizacao;
    private int CNPJ; 
    private int notaDeQualiadade; 

    public Universidade (String nome, String localizacao, int CNPJ, int notaDeQualiadade) {
        this.nome = nome;
        this.localizacao = localizacao; 
        this.CNPJ = CNPJ;
        this.notaDeQualiadade = notaDeQualiadade;
    }

    public String getNome() {
        return nome;
    }
    public String getLocalizacao() {
        return localizacao;
    }
    public int getCNPJ() {
        return CNPJ;
    }
    public int getNotaDeQualidade() {
        return notaDeQualiadade;
    }
}