package ExercicioDois;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        
        Pessoa pessoa = new Pessoa();
        
        pessoa.setNome("Julia Mariano");
        pessoa.setPeso("57Kg");
        pessoa.setAltura("1.52cm");
        pessoa.setSigno("Libra");
        pessoa.setStatusCivil("Casada");
        pessoa.setSexo("Feminino");
        
        System.out.println("Nome: " + pessoa.getNome());
        System.out.println("Peso: " + pessoa.getPeso());
        System.out.println("Altura: " + pessoa.getAltura());
        System.out.println("Signo: " + pessoa.getSigno());
        System.out.println("Status Civil: " + pessoa.getStatusCivil());
        System.out.println("Sexo: " + pessoa.getSexo());
    }
}
