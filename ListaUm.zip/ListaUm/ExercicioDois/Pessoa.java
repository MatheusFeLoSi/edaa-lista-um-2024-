package ExercicioDois;

public class Pessoa {
    
    private String nome;
    private String peso;
    private String altura;
    private String signo;
    private String statusCivil; 
    private String sexo;

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getPeso() {
        return peso;
    }
    public void setPeso(String peso) {
        this.peso = peso;
    }
    
    public String getAltura() {
        return altura;
    }
    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getSigno() {
        return signo;
    }
    public void setSigno(String signo) {
        this.signo = signo;
    }

    public String getStatusCivil() {
        return statusCivil;
    }
    public void setStatusCivil(String statusCivil) {
        this.statusCivil = statusCivil;
    }

    public String getSexo() {
        return sexo;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
}

