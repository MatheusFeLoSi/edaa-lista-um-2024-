package ExercicioQuatro;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();

        cachorro.setTipo("Cachorro.");
        cachorro.setRaca("Husky.");
        cachorro.setPorte("Grande.");
        cachorro.setHabitat("Quintal de casa.");
        cachorro.setNome("Sadan.");
        cachorro.setIdade(2);
        System.out.println("Nome do cachorro: " + cachorro.getNome());
        System.out.println("Idade: " + cachorro.getIdade());
        System.out.println("Habitat: " + cachorro.getHabitat());
        cachorro.sentar();
    }
}
