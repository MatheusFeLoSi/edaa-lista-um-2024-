package ExercicioUm;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        Livro livro = new Livro(); 

        livro.setNome("Textos crueis demais.");
        livro.setGenero("Auto-ajuda.");
        livro.setAutor("Igor Pires, Gabriela Barreira.");
        livro.setQtdepaginas("Possue 304 páginas.");
    
        System.out.println("Nome do livro: " + livro.getNome());
        System.out.println("Genero: " + livro.getGenero());
        System.out.println("Autor: " + livro.getAutor());
        System.out.println("Quantidade de paginas: " + livro.getQtdepaginas());
    }
}

